[Backup]

據說是有問題的 Chrome plugin 
下載連結 : https://chrome.google.com/webstore/detail/user-agent-switcher-for-g/ffhkkpnppgnfaobgihpdblnhmmbodake/reviews

相關連結 （教學） :
http://www.freebuf.com/news/147188.html
https://www.v2ex.com/t/389340?p=1

Note :
有問題的路徑為 ChromePluginBackdoor / js / background.js
函數為第 80 行

09/12
因為 80 行一坨太難看 , 新增檔案 payload.js , 把第 80 行的部分整理一下
